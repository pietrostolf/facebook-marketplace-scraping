--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE vehicle_clean_labeled_2;
--
-- Name: vehicle_clean_labeled_2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE vehicle_clean_labeled_2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Canada.1252';


ALTER DATABASE vehicle_clean_labeled_2 OWNER TO postgres;

\connect vehicle_clean_labeled_2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: vehicle_listings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicle_listings (
    id integer NOT NULL,
    "City" character varying,
    "Province" character varying,
    "Year" integer,
    "Make" character varying,
    "Model" character varying,
    "Price" double precision,
    "Mileage" integer,
    "URL" character varying,
    "Rebuilt_Predicted" integer
);


ALTER TABLE public.vehicle_listings OWNER TO postgres;

--
-- Name: vehicle_listings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vehicle_listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicle_listings_id_seq OWNER TO postgres;

--
-- Name: vehicle_listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vehicle_listings_id_seq OWNED BY public.vehicle_listings.id;


--
-- Name: vehicle_listings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle_listings ALTER COLUMN id SET DEFAULT nextval('public.vehicle_listings_id_seq'::regclass);


--
-- Data for Name: vehicle_listings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehicle_listings (id, "City", "Province", "Year", "Make", "Model", "Price", "Mileage", "URL", "Rebuilt_Predicted") FROM stdin;
\.
COPY public.vehicle_listings (id, "City", "Province", "Year", "Make", "Model", "Price", "Mileage", "URL", "Rebuilt_Predicted") FROM '$$PATH$$/3319.dat';

--
-- Name: vehicle_listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vehicle_listings_id_seq', 484, true);


--
-- Name: vehicle_listings vehicle_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle_listings
    ADD CONSTRAINT vehicle_listings_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

